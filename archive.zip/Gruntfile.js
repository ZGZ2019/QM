module.exports=function(s){"use strict";s.loadNpmTasks("@sap/grunt-sapui5-bestpractice-build");s.registerTask("default",["clean","lint","build"])};
//# sourceMappingURL=Gruntfile.js.map